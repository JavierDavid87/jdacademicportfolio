const categories = [
  { id: "quiz", name: "Quiz", icon: "📝" },
  { id: "longquiz", name: "Long Quiz", icon: "📋" },
  { id: "activity", name: "Activity", icon: "⚡" },
  { id: "midterms", name: "Midterms", icon: "📘" },
  { id: "finals", name: "Finals", icon: "🎓" },
  { id: "project", name: "Project", icon: "🚀" }
];

const DB_NAME = "AcademicPortfolioDB";
const DB_VERSION = 1;
let db;

const $ = id => document.getElementById(id);

function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = e => {
      const database = e.target.result;
      if (!database.objectStoreNames.contains("items")) {
        database.createObjectStore("items", { keyPath: "id", autoIncrement: true });
      }
    };
    request.onsuccess = e => { db = e.target.result; resolve(db); };
    request.onerror = () => reject(request.error);
  });
}

function addItem(item) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction("items", "readwrite");
    const req = tx.objectStore("items").add(item);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
function getAllItems() {
  return new Promise((resolve, reject) => {
    const tx = db.transaction("items", "readonly");
    const req = tx.objectStore("items").getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
function deleteItem(id) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction("items", "readwrite");
    tx.objectStore("items").delete(id);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

function loadSettings() {
  const profile = JSON.parse(localStorage.getItem("portfolioProfile") || "{}");
  $("homeName").textContent = profile.name || "Your Name";
  $("infoName").textContent = profile.name || "Your Name";
  $("homeCourse").textContent = profile.course ? `Student • ${profile.course}` : "Student • Your Program";
  $("infoCourse").textContent = profile.course || "Your Program";
  $("infoYear").textContent = profile.year || "Year / Section";
  $("infoGoal").textContent = profile.goal || "To keep learning and improving";
  $("aboutText").value = localStorage.getItem("portfolioAbout") || "";
  const savedProfile = localStorage.getItem("portfolioProfileImage");
  if (savedProfile) showProfile(savedProfile);
}
function saveProfile() {
  const profile = {
    name: $("nameInput").value.trim() || "Your Name",
    course: $("courseInput").value.trim() || "Your Program",
    year: $("yearInput").value.trim() || "Year / Section",
    goal: $("goalInput").value.trim() || "To keep learning and improving"
  };
  localStorage.setItem("portfolioProfile", JSON.stringify(profile));
  loadSettings();
  $("profileModal").classList.add("hidden");
}
function showProfile(src) {
  $("profileImage").src = src;
  $("profileImage").style.display = "block";
  $("profilePlaceholder").style.display = "none";
}

function makeCategoryCard(cat) {
  const card = document.createElement("article");
  card.className = "glass-card score-card reveal";
  card.innerHTML = `
    <div class="score-top">
      <div style="display:flex;align-items:center;gap:12px">
        <div class="score-icon">${cat.icon}</div>
        <div><h3>${cat.name}</h3><small style="color:#7890aa">Results & supporting files</small></div>
      </div>
      <span class="badge">MULTIPLE</span>
    </div>
    <div class="upload-area">
      <label>
        + Upload Images / Files
        <input type="file" class="category-input" data-category="${cat.id}" multiple>
      </label>
    </div>
    <div class="media-list" id="list-${cat.id}"></div>
  `;
  $("scoreGrid").appendChild(card);
  card.querySelector("input").addEventListener("change", handleFiles);
}

async function handleFiles(e) {
  const category = e.target.dataset.category;
  const files = [...e.target.files];
  for (const file of files) {
    await addItem({
      category,
      name: file.name,
      type: file.type || "application/octet-stream",
      size: file.size,
      blob: file,
      created: Date.now()
    });
  }
  e.target.value = "";
  await renderAll();
}

function formatSize(bytes) {
  if (!bytes) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(i ? 1 : 0)} ${units[i]}`;
}

function createOpenLink(item) {
  const url = URL.createObjectURL(item.blob);
  const a = document.createElement("a");
  a.href = url;
  a.target = "_blank";
  a.rel = "noopener";
  a.className = "small-btn";
  a.textContent = "View";
  return { a, url };
}

async function renderAll() {
  const items = await getAllItems();
  categories.forEach(cat => {
    const list = $(`list-${cat.id}`);
    list.innerHTML = "";
    const categoryItems = items.filter(x => x.category === cat.id);
    if (!categoryItems.length) {
      list.innerHTML = `<div class="empty">No uploads yet.</div>`;
      return;
    }
    categoryItems.forEach(item => {
      const wrap = document.createElement("div");
      wrap.className = "media-item";
      if (item.type.startsWith("image/")) {
        const img = document.createElement("img");
        img.src = URL.createObjectURL(item.blob);
        img.alt = item.name;
        img.title = "Click to view";
        img.onclick = () => window.open(img.src, "_blank");
        wrap.appendChild(img);
      } else {
        const row = document.createElement("div");
        row.className = "file-item";
        row.innerHTML = `<span style="font-size:1.3rem">📄</span><span class="file-name">${escapeHTML(item.name)}</span>`;
        const actions = document.createElement("div");
        actions.className = "file-actions";
        const { a, url } = createOpenLink(item);
        const dl = document.createElement("a");
        dl.href = url; dl.download = item.name; dl.className = "small-btn"; dl.textContent = "Download";
        const del = document.createElement("button");
        del.className = "small-btn"; del.textContent = "Delete";
        del.onclick = async () => { await deleteItem(item.id); renderAll(); };
        actions.append(a, dl, del);
        row.appendChild(actions);
        wrap.appendChild(row);
      }
      if (item.type.startsWith("image/")) {
        const actions = document.createElement("div");
        actions.className = "file-actions";
        actions.style.marginTop = "7px";
        const dl = document.createElement("a");
        const url = URL.createObjectURL(item.blob);
        dl.href = url; dl.download = item.name; dl.className = "small-btn"; dl.textContent = "Download";
        const del = document.createElement("button");
        del.className = "small-btn"; del.textContent = "Delete";
        del.onclick = async () => { await deleteItem(item.id); renderAll(); };
        actions.append(dl, del);
        wrap.appendChild(actions);
      }
      list.appendChild(wrap);
    });
  });

  const all = $("allFiles");
  all.innerHTML = "";
  if (!items.length) {
    all.innerHTML = `<div class="empty">No files uploaded yet. Your uploaded documents will appear here.</div>`;
    return;
  }
  items.sort((a,b) => b.created - a.created).forEach(item => {
    const cat = categories.find(c => c.id === item.category);
    const row = document.createElement("div");
    row.className = "file-row";
    const url = URL.createObjectURL(item.blob);
    row.innerHTML = `
      <span style="font-size:1.2rem">${item.type.startsWith("image/") ? "🖼️" : "📄"}</span>
      <span style="flex:1;min-width:0"><strong style="display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escapeHTML(item.name)}</strong>
      <small class="category-label">${cat ? cat.name : "File"} • ${formatSize(item.size)}</small></span>
    `;
    const view = document.createElement("a");
    view.href = url; view.target = "_blank"; view.className = "small-btn"; view.textContent = "View";
    const dl = document.createElement("a");
    dl.href = url; dl.download = item.name; dl.className = "small-btn"; dl.textContent = "Download";
    row.append(view, dl);
    all.appendChild(row);
  });
}
function escapeHTML(str) {
  return str.replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;" }[c]));
}

function setupReveal() {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => { if (entry.isIntersecting) entry.target.classList.add("visible"); });
  }, { threshold: .08 });
  document.querySelectorAll(".reveal").forEach(el => observer.observe(el));
}

$("profileInput").addEventListener("change", e => {
  const file = e.target.files[0];
  if (!file || !file.type.startsWith("image/")) return;
  const reader = new FileReader();
  reader.onload = () => {
    localStorage.setItem("portfolioProfileImage", reader.result);
    showProfile(reader.result);
  };
  reader.readAsDataURL(file);
});
$("saveAbout").onclick = () => {
  localStorage.setItem("portfolioAbout", $("aboutText").value);
  alert("About Me saved successfully.");
};
$("editProfile").onclick = () => {
  const p = JSON.parse(localStorage.getItem("portfolioProfile") || "{}");
  $("nameInput").value = p.name || "";
  $("courseInput").value = p.course || "";
  $("yearInput").value = p.year || "";
  $("goalInput").value = p.goal || "";
  $("profileModal").classList.remove("hidden");
};
$("closeModal").onclick = () => $("profileModal").classList.add("hidden");
$("saveProfile").onclick = saveProfile;
$("profileModal").addEventListener("click", e => {
  if (e.target === $("profileModal")) $("profileModal").classList.add("hidden");
});
$("menuToggle").onclick = () => $("navMenu").classList.toggle("open");
$("year").textContent = new Date().getFullYear();

(async function init() {
  try {
    await openDB();
    categories.forEach(makeCategoryCard);
    loadSettings();
    await renderAll();
    setupReveal();
  } catch (err) {
    console.error(err);
    alert("Your browser could not initialize local file storage. Try Chrome or Edge.");
  }
})();
